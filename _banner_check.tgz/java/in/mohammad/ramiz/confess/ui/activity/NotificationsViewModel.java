package in.mohammad.ramiz.confess.ui.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import in.mohammad.ramiz.confess.core.ActivityEvents;
import in.mohammad.ramiz.confess.core.Event;
import in.mohammad.ramiz.confess.data.api.ApiCallback;
import in.mohammad.ramiz.confess.data.api.ApiException;
import in.mohammad.ramiz.confess.data.local.LocalStore;
import in.mohammad.ramiz.confess.data.model.Notification;
import in.mohammad.ramiz.confess.data.model.NotificationPage;
import in.mohammad.ramiz.confess.data.repo.ActivityRepository;
import in.mohammad.ramiz.confess.data.repo.PostRepository;
import retrofit2.Call;

/**
 * Activity list (server-side now; the old app kept a local Room table of pushes).
 * Newest first, cursor paging, read state per item, filter by kind on device.
 * Saved on the phone (per Everyone / Following): it opens at once with what came last time,
 * then the fresh list replaces it (not re-fetched within 20 s).
 */
public class NotificationsViewModel extends ViewModel {

    public enum Screen { LOADING, CONTENT, EMPTY, ERROR }

    public enum Footer { NONE, LOADING, ERROR, END }

    public enum Filter { ALL, FELT, RESPONSES, FOLLOWS }

    public static final class State {
        @NonNull public final Screen screen;
        /** Already filtered. */
        @NonNull public final List<Notification> items;
        @NonNull public final Footer footer;
        @NonNull public final Filter filter;
        public final boolean refreshing;
        public final boolean anyUnread;
        @Nullable public final ApiException error;

        State(@NonNull Screen screen, @NonNull List<Notification> items, @NonNull Footer footer,
              @NonNull Filter filter, boolean refreshing, boolean anyUnread, @Nullable ApiException error) {
            this.screen = screen;
            this.items = Collections.unmodifiableList(items);
            this.footer = footer;
            this.filter = filter;
            this.refreshing = refreshing;
            this.anyUnread = anyUnread;
            this.error = error;
        }
    }

    private static final long FRESH_MS = 20_000;

    private final ActivityRepository repo = new ActivityRepository();
    @Nullable private final LocalStore local = LocalStore.get();
    private final MutableLiveData<State> state = new MutableLiveData<>();
    private final MutableLiveData<Event<ApiException>> errors = new MutableLiveData<>();

    private final List<Notification> all = new ArrayList<>();
    private Screen screen = Screen.LOADING;
    private Footer footer = Footer.NONE;
    private Filter filter = Filter.ALL;
    /** PostRepository.SCOPE_ALL or SCOPE_FOLLOWING (only activity by people I follow). */
    private String scope = PostRepository.SCOPE_ALL;
    private boolean refreshing, loaded;
    @Nullable private String cursor;
    @Nullable private ApiException error;
    @Nullable private Call<NotificationPage> firstCall, moreCall;

    public LiveData<State> state() { return state; }
    public LiveData<Event<ApiException>> errors() { return errors; }

    public void start() {
        if (loaded || firstCall != null) return;
        if (restore()) {
            publish();
            if (local == null || local.ageMs(storeKey()) > FRESH_MS) loadFirst();
            return;
        }
        screen = Screen.LOADING;
        publish();
        loadFirst();
    }

    @NonNull
    private String storeKey() {
        return "activity/" + scope;
    }

    private boolean restore() {
        if (local == null) return false;
        NotificationPage saved = local.read(storeKey(), NotificationPage.class);
        if (saved == null || saved.notifications == null || saved.notifications.isEmpty()) return false;
        all.clear();
        addUnique(saved.notifications);
        cursor = saved.nextCursor;
        loaded = true;
        footer = cursor == null ? Footer.END : Footer.NONE;
        screen = Screen.CONTENT;
        error = null;
        return true;
    }

    private void persist() {
        if (local == null || !loaded) return;
        NotificationPage page = new NotificationPage();
        int n = Math.min(all.size(), 100);
        page.notifications = new ArrayList<>(all.subList(0, n));
        page.nextCursor = n == all.size() ? cursor : null;
        local.write(storeKey(), page);
    }

    public void refresh() {
        if (firstCall != null) return;
        if (screen == Screen.ERROR) screen = Screen.LOADING; else refreshing = true;
        publish();
        loadFirst();
    }

    private void loadFirst() {
        if (moreCall != null) { moreCall.cancel(); moreCall = null; }
        firstCall = repo.notifications(scope, null, new ApiCallback<NotificationPage>() {
            @Override
            public void onSuccess(NotificationPage page) {
                firstCall = null;
                loaded = true;
                refreshing = false;
                all.clear();
                addUnique(page.notifications);
                cursor = page.nextCursor;
                footer = cursor == null ? Footer.END : Footer.NONE;
                error = null;
                screen = Screen.CONTENT;
                publish();
                persist();
            }

            @Override
            public void onError(ApiException e) {
                firstCall = null;
                refreshing = false;
                if (all.isEmpty()) { screen = Screen.ERROR; error = e; }
                else errors.setValue(new Event<>(e));
                publish();
            }
        });
    }

    public void loadMore() {
        if (!loaded || cursor == null || moreCall != null || firstCall != null || footer == Footer.ERROR) return;
        footer = Footer.LOADING;
        publish();
        moreCall = repo.notifications(scope, cursor, new ApiCallback<NotificationPage>() {
            @Override
            public void onSuccess(NotificationPage page) {
                moreCall = null;
                addUnique(page.notifications);
                cursor = page.nextCursor;
                footer = cursor == null ? Footer.END : Footer.NONE;
                publish();
                persist();
            }

            @Override
            public void onError(ApiException e) {
                moreCall = null;
                footer = Footer.ERROR;
                publish();
            }
        });
    }

    public void retryMore() {
        if (footer == Footer.ERROR) footer = Footer.NONE;
        loadMore();
    }

    /** Everyone / Following: a different list from the server, so start over. */
    public void setScope(@NonNull String next) {
        if (next.equals(scope)) return;
        scope = next;
        if (firstCall != null) { firstCall.cancel(); firstCall = null; }
        if (moreCall != null) { moreCall.cancel(); moreCall = null; }
        all.clear();
        cursor = null;
        loaded = false;
        error = null;
        refreshing = false;
        footer = Footer.NONE;
        if (restore()) {
            publish();
            loadFirst();
            return;
        }
        screen = Screen.LOADING;
        publish();
        loadFirst();
    }

    @NonNull
    public String scope() {
        return scope;
    }

    public void setFilter(@NonNull Filter f) {
        if (f == filter) return;
        filter = f;
        publish();
    }

    // ── Read state ───────────────────────────────────────────────────────────

    public boolean anyUnread() {
        for (Notification n : all) if (!n.read) return true;
        return false;
    }

    /** Tapped one: mark it read here and on the server (best effort). */
    public void markRead(@NonNull Notification n) {
        if (n.read) return;
        setRead(n.id);
        publish();
        persist();
        repo.markRead(Collections.singletonList(n.id), ignore());
    }

    /** "Mark all read" (and quietly when leaving the screen). */
    public void markAllRead(boolean publishNow) {
        if (!anyUnread()) return;
        for (int i = 0; i < all.size(); i++) if (!all.get(i).read) setRead(all.get(i).id);
        if (publishNow) publish();
        persist();
        repo.markRead(null, new ApiCallback<JsonObject>() {
            @Override public void onSuccess(JsonObject data) { ActivityEvents.ping(); }   // home's bell re-checks
            @Override public void onError(ApiException e) { }
        });
    }

    private void setRead(String id) {
        for (int i = 0; i < all.size(); i++) {
            Notification n = all.get(i);
            if (id.equals(n.id) && !n.read) {
                Notification c = copy(n);
                c.read = true;
                all.set(i, c);                     // new object so the list diff sees the change
            }
        }
    }

    private static Notification copy(Notification n) {
        Notification c = new Notification();
        c.id = n.id;
        c.type = n.type;
        c.actor = n.actor;
        c.postId = n.postId;
        c.postExcerpt = n.postExcerpt;
        c.commentExcerpt = n.commentExcerpt;
        c.read = n.read;
        c.createdAt = n.createdAt;
        return c;
    }

    private static ApiCallback<JsonObject> ignore() {
        return new ApiCallback<JsonObject>() {
            @Override public void onSuccess(JsonObject data) { }
            @Override public void onError(ApiException e) { }
        };
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void addUnique(List<Notification> incoming) {
        outer:
        for (Notification n : incoming) {
            if (n == null || n.id == null) continue;
            for (Notification have : all) if (have.id.equals(n.id)) continue outer;
            all.add(n);
        }
    }

    private void publish() {
        List<Notification> shown = new ArrayList<>();
        for (Notification n : all) {
            boolean keep;
            switch (filter) {
                case FELT: keep = Notification.TYPE_LIKE.equals(n.type); break;
                case RESPONSES: keep = Notification.TYPE_COMMENT.equals(n.type); break;
                case FOLLOWS: keep = Notification.TYPE_FOLLOW.equals(n.type); break;
                default: keep = true;
            }
            if (keep) {
                shown.add(n);
            }
        }
        Screen s = screen == Screen.CONTENT && all.isEmpty() ? Screen.EMPTY : screen;
        state.setValue(new State(s, shown, s == Screen.CONTENT ? footer : Footer.NONE, filter,
                refreshing, anyUnread(), error));
    }

    @Override
    protected void onCleared() {
        if (firstCall != null) firstCall.cancel();
        if (moreCall != null) moreCall.cancel();
    }
}
