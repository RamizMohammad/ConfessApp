package in.mohammad.ramiz.confess.ui.entry;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import in.mohammad.ramiz.confess.BuildConfig;
import in.mohammad.ramiz.confess.R;

import in.mohammad.ramiz.confess.data.api.ApiCallback;
import in.mohammad.ramiz.confess.data.api.ApiException;
import in.mohammad.ramiz.confess.data.model.Me;
import in.mohammad.ramiz.confess.data.repo.AuthRepository;
import in.mohammad.ramiz.confess.data.repo.UserRepository;
import in.mohammad.ramiz.confess.data.security.AppSignature;
import in.mohammad.ramiz.confess.data.session.SessionManager;
import in.mohammad.ramiz.confess.ui.auth.GoogleAuth;
import in.mohammad.ramiz.confess.core.DeepLink;
import in.mohammad.ramiz.confess.ui.base.Router;

/**
 * Splash + router. No UI of its own: the system splash (ink + logo) stays up
 * while we decide where to go.
 *
 *   copy not signed by us (release) → blocking notice, nothing else runs
 *   refreshable session              → (unlock | home); the network layer refreshes tokens
 *   old-style session (older app)    → quiet Google re-sign-in to get a refreshable one
 *                                      (falls back to the current token while it's valid)
 *   no session                       → Welcome
 *
 * The splash plays Letty's opening (splash_letty_anim) and, on the way out, zooms her into
 * the app ({@link #playOut}).
 */
public class LauncherActivity extends AppCompatActivity {

    /** Never keep the splash longer than this, whatever the network does. */
    private static final long MAX_WAIT_MS = 8_000;

    /** Long enough for Letty's splash animation (splash_letty_anim, 1000 ms) to finish on a fresh launch. */
    private static final long MIN_SPLASH_MS = 1050;

    private boolean decided = false;
    /** The splash stays up until we actually leave, so it never uncovers this empty screen. */
    private boolean leaving = false;
    private long holdSplashUntil = 0;
    private final Handler handler = new Handler(Looper.getMainLooper());
    @Nullable private CancellationSignal googleCancel;
    /** Where to go once the splash has played its way out. */
    @Nullable private Destination pending;
    private boolean gone = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SplashScreen splash = SplashScreen.installSplashScreen(this);
        super.onCreate(savedInstanceState);
        splash.setKeepOnScreenCondition(() -> !leaving);
        splash.setOnExitAnimationListener(this::playOut);
        if (savedInstanceState == null) holdSplashUntil = SystemClock.uptimeMillis() + MIN_SPLASH_MS;
        DeepLink.capture(getIntent());            // tapped a push → open that confession once in

        if (!BuildConfig.DEBUG && !AppSignature.isGenuine(this)) {
            decided = true;
            leaving = true;
            showTampered();
            return;
        }

        SessionManager session = SessionManager.get();
        if (!session.isSignedIn() && !session.needsUpgrade()) {
            session.clear();
            finishWith(Router::toWelcome);
            return;
        }
        if (session.isRefreshable()) {
            refreshProfileQuietly();
            finishWith(Router::toApp);
            return;
        }

        // Old-style session from an earlier version: upgrade with a quiet Google re-sign-in.
        handler.postDelayed(this::fallback, MAX_WAIT_MS);
        googleCancel = GoogleAuth.silent(this, new GoogleAuth.Callback() {
            @Override
            public void onIdToken(@NonNull String idToken) {
                new AuthRepository().login(idToken, new ApiCallback<Me>() {
                    @Override
                    public void onSuccess(Me me) {
                        finishWith(Router::toApp);
                    }

                    @Override
                    public void onError(ApiException error) {
                        fallback();
                    }
                });
            }

            @Override
            public void onCancelled() {
                fallback();
            }

            @Override
            public void onFailed(@NonNull String reason) {
                fallback();
            }
        });
    }

    /** Couldn't refresh: keep going if the old token still works, else start over. */
    private void fallback() {
        if (SessionManager.get().isSignedIn()) {
            finishWith(Router::toApp);
        } else {
            SessionManager.get().clear();
            finishWith(Router::toWelcome);
        }
    }

    private void refreshProfileQuietly() {
        new UserRepository().me(new ApiCallback<Me>() {
            @Override public void onSuccess(Me data) { }    // cached by the repository
            @Override public void onError(ApiException error) { }
        });
    }

    /** Re-signed APK: no sign-in, no network — just say so and point to the real app. */
    private void showTampered() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.tampered_title)
                .setMessage(R.string.tampered_body)
                .setCancelable(false)
                .setPositiveButton(R.string.tampered_action, (d, w) -> {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://play.google.com/store/apps/details?id=" + getPackageName())));
                    } catch (Exception ignored) {
                        // no browser / store
                    }
                    finishAndRemoveTask();
                })
                .show();
    }

    private interface Destination {
        void go(AppCompatActivity from);
    }

    private void finishWith(Destination destination) {
        if (decided) return;
        decided = true;
        handler.removeCallbacksAndMessages(null);
        long wait = Math.max(0, holdSplashUntil - SystemClock.uptimeMillis());
        pending = destination;
        handler.postDelayed(() -> {
            leaving = true;                              // → playOut, which then goes
            handler.postDelayed(this::go, 1500);         // in case the exit animation never comes
        }, wait);
    }

    /**
     * The splash leaves: Letty dips, then zooms toward you and fades as the dark curtain lifts —
     * straight into the app (whose background is the same ink, so nothing flashes).
     */
    private void playOut(@NonNull androidx.core.splashscreen.SplashScreenViewProvider provider) {
        android.view.View screen = provider.getView();
        android.view.View icon = provider.getIconView();
        if (!android.animation.ValueAnimator.areAnimatorsEnabled() || pending == null) {
            provider.remove();
            go();
            return;
        }
        if (icon != null) {
            icon.animate().scaleX(0.9f).scaleY(0.9f).setDuration(110)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator())
                    .withEndAction(() -> icon.animate().scaleX(2.6f).scaleY(2.6f).alpha(0f).setDuration(340)
                            .setInterpolator(new android.view.animation.AccelerateInterpolator(1.4f)).start())
                    .start();
        }
        screen.animate().alpha(0f).setStartDelay(220).setDuration(260)
                .withEndAction(() -> {
                    provider.remove();
                    go();
                }).start();
    }

    private void go() {
        if (gone || pending == null) return;
        gone = true;
        handler.removeCallbacksAndMessages(null);
        pending.go(this);                                // Router fades into the next screen
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (googleCancel != null) googleCancel.cancel();
        super.onDestroy();
    }
}
