package in.mohammad.ramiz.confess.data.gif;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.LruCache;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import in.mohammad.ramiz.confess.data.api.ApiCallback;
import in.mohammad.ramiz.confess.data.api.ApiClient;
import in.mohammad.ramiz.confess.data.api.ApiException;
import in.mohammad.ramiz.confess.data.api.Calls;
import in.mohammad.ramiz.confess.data.model.Gif;
import in.mohammad.ramiz.confess.data.model.GifPage;
import retrofit2.Call;

/**
 * GIF search for the picker — through our server (GET /api/v2/gifs), never straight to GIPHY.
 *
 * GIPHY counts calls per key for the whole app (100 an hour on a beta key), so the server
 * keeps one shared cache and an hourly budget, and the key never ships in the APK. This side
 * adds a small in-app cache (10 minutes), so going back to a search or to trending costs nothing.
 */
public final class GiphyClient {

    public interface Callback {
        /** Main thread. {@code more}: there's another page at {@code nextOffset}. */
        void onResult(@NonNull List<Gif> gifs, int nextOffset, boolean more);

        void onError(@NonNull ApiException e);
    }

    /** Searches shorter than this aren't sent (one letter matches everything). */
    public static final int MIN_QUERY = 2;

    private static final long KEEP_MS = 10 * 60_000L;
    private static final LruCache<String, Saved> CACHE = new LruCache<>(60);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final class Saved {
        final GifPage page;
        final long at;

        Saved(GifPage page) {
            this.page = page;
            this.at = SystemClock.elapsedRealtime();
        }
    }

    private GiphyClient() { }

    /** How the server matches searches: lower case, single spaces. */
    @NonNull
    public static String normalise(@Nullable String q) {
        return q == null ? "" : q.trim().replaceAll("\\s+", " ").toLowerCase(Locale.ROOT);
    }

    /** Trending (empty query) or a search. Returns the call to cancel, or null when answered from the cache. */
    @Nullable
    public static Call<GifPage> load(@Nullable String query, int offset, @NonNull Callback cb) {
        String q = normalise(query);
        String key = q + "#" + offset;
        Saved saved = CACHE.get(key);
        if (saved != null && SystemClock.elapsedRealtime() - saved.at < KEEP_MS) {
            MAIN.post(() -> deliver(saved.page, cb));
            return null;
        }
        return Calls.enqueue(ApiClient.api().gifs(q.isEmpty() ? null : q, offset), new ApiCallback<GifPage>() {
            @Override
            public void onSuccess(GifPage page) {
                if (page == null) page = new GifPage();
                CACHE.put(key, new Saved(page));
                deliver(page, cb);
            }

            @Override
            public void onError(ApiException e) {
                cb.onError(e);
            }
        });
    }

    private static void deliver(@NonNull GifPage page, @NonNull Callback cb) {
        List<Gif> gifs = page.gifs == null ? new ArrayList<>() : page.gifs;
        cb.onResult(gifs, page.nextOffset, page.more);
    }
}
