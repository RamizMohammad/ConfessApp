package in.mohammad.ramiz.confess.ui.tour;

import android.animation.ValueAnimator;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.util.List;

import in.mohammad.ramiz.confess.R;
import in.mohammad.ramiz.confess.core.Haptics;
import in.mohammad.ramiz.confess.databinding.ActivityTourBinding;
import in.mohammad.ramiz.confess.ui.base.BaseActivity;
import in.mohammad.ramiz.confess.ui.util.EdgeInsets;

/**
 * The feature tour, a page at a time — text first, gently animated: the icon pops in and floats,
 * the title types itself out, then the line and the points ease in one after another. Swipe or
 * tap Next; Skip any time. Phone animations off → everything simply appears.
 *
 * MODE_FULL: every page (new installs, Settings → Take the tour).
 * MODE_NEW: what's new since the version last seen, with "See the full tour" at the end.
 */
public class TourActivity extends BaseActivity {

    public static final String EXTRA_MODE = "mode";
    public static final int MODE_FULL = 0, MODE_NEW = 1;

    private static final long TYPE_MS = 26;
    private static final String STATE_INDEX = "index";

    private ActivityTourBinding b;
    private List<Tour.Page> pages;
    private int index = 0;
    private int mode;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueAnimator floatAnim;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        b = ActivityTourBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        EdgeInsets.padTop(b.topBar);
        EdgeInsets.padBottom(b.bottom, false);

        mode = getIntent().getIntExtra(EXTRA_MODE, MODE_FULL);
        pages = mode == MODE_NEW ? Tour.whatsNew(Tour.seenVersion(this)) : Tour.full();
        if (pages.isEmpty()) pages = Tour.full();
        if (savedInstanceState != null) index = Math.min(savedInstanceState.getInt(STATE_INDEX, 0), pages.size() - 1);

        b.skip.setOnClickListener(v -> finishTour());
        b.next.setOnClickListener(v -> {
            Haptics.tick(this);
            if (index < pages.size() - 1) go(index + 1);
            else finishTour();
        });
        b.fullTour.setOnClickListener(v -> {
            Haptics.tick(this);
            mode = MODE_FULL;
            pages = Tour.full();
            buildDots();
            go(0);
        });

        // Swipe between pages.
        GestureDetector swipe = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(@NonNull MotionEvent e) { return true; }

            @Override
            public boolean onFling(MotionEvent e1, @NonNull MotionEvent e2, float vx, float vy) {
                if (e1 == null) return false;
                float dx = e2.getX() - e1.getX();
                if (Math.abs(dx) < dp(60) || Math.abs(dx) < Math.abs(e2.getY() - e1.getY())) return false;
                if (dx < 0 && index < pages.size() - 1) { Haptics.tick(TourActivity.this); go(index + 1); }
                else if (dx > 0 && index > 0) { Haptics.tick(TourActivity.this); go(index - 1); }
                return true;
            }
        });
        b.page.setOnTouchListener((v, ev) -> swipe.onTouchEvent(ev));

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (index > 0) go(index - 1); else finishTour();
            }
        });

        buildDots();
        show(index, 0);
        startFloating();
    }

    private void go(int to) {
        if (to == index || to < 0 || to >= pages.size()) {
            if (to == index) show(index, 0);
            return;
        }
        int dir = to > index ? 1 : -1;
        index = to;
        if (!ValueAnimator.areAnimatorsEnabled()) {
            show(index, 0);
            return;
        }
        b.page.animate().cancel();
        b.page.animate().translationX(-dir * dp(40)).alpha(0f).setDuration(150)
                .withEndAction(() -> show(index, dir)).start();
    }

    /** Lay out page i; {@code dir} = where it slides in from (0 = no slide). */
    private void show(int i, int dir) {
        handler.removeCallbacksAndMessages(null);
        Tour.Page p = pages.get(i);
        boolean motion = ValueAnimator.areAnimatorsEnabled();
        String title = getString(p.title);

        b.step.setText(getString(R.string.tour_step, i + 1, pages.size()));
        b.page.setContentDescription(getString(R.string.cd_tour_page, i + 1, pages.size()));
        b.icon.setImageResource(p.icon);
        int size = dp(p.brand ? 72 : 48);
        b.icon.getLayoutParams().width = size;
        b.icon.getLayoutParams().height = size;
        b.icon.requestLayout();
        b.icon.setImageTintList(p.brand ? null : ColorStateList.valueOf(ContextCompat.getColor(this, R.color.amber)));
        b.badge.setVisibility(p.isNew() ? View.VISIBLE : View.GONE);
        b.title.setContentDescription(title);
        b.body.setText(p.body);
        b.points.removeAllViews();
        for (int res : p.points) b.points.addView(point(getString(res)));

        boolean last = i == pages.size() - 1;
        b.next.setText(last ? R.string.tour_done : R.string.tour_next);
        b.next.setIconResource(last ? 0 : R.drawable.ic_arrow_right);
        b.skip.setVisibility(last ? View.INVISIBLE : View.VISIBLE);
        b.fullTour.setVisibility(last && mode == MODE_NEW ? View.VISIBLE : View.GONE);
        paintDots();

        if (!motion) {
            b.page.setTranslationX(0f);
            b.page.setAlpha(1f);
            b.title.setText(title);
            return;
        }

        // Slide the page in.
        b.page.setTranslationX(dir * dp(40));
        b.page.setAlpha(dir == 0 ? 1f : 0f);
        b.page.animate().translationX(0f).alpha(1f).setDuration(220)
                .setInterpolator(new DecelerateInterpolator()).start();

        // Icon pops in.
        b.iconDisc.setScaleX(0.6f);
        b.iconDisc.setScaleY(0.6f);
        b.iconDisc.animate().scaleX(1f).scaleY(1f).setDuration(420)
                .setInterpolator(new OvershootInterpolator(2.2f)).start();
        if (p.isNew()) {
            b.badge.setAlpha(0f);
            b.badge.animate().alpha(1f).setStartDelay(160).setDuration(220).start();
        }

        // Title types itself; then the line and the points ease in.
        b.title.setText("");
        b.body.setAlpha(0f);
        for (int k = 0; k < b.points.getChildCount(); k++) {
            View v = b.points.getChildAt(k);
            v.setAlpha(0f);
            v.setTranslationY(dp(10));
        }
        long start = 180;
        for (int c = 1; c <= title.length(); c++) {
            final int n = c;
            handler.postDelayed(() -> b.title.setText(title.substring(0, n)), start + c * TYPE_MS);
        }
        long after = start + title.length() * TYPE_MS + 80;
        b.body.animate().alpha(1f).setStartDelay(after).setDuration(260).start();
        for (int k = 0; k < b.points.getChildCount(); k++) {
            b.points.getChildAt(k).animate().alpha(1f).translationY(0f)
                    .setStartDelay(after + 160 + 110L * k).setDuration(260)
                    .setInterpolator(new DecelerateInterpolator()).start();
        }
    }

    /** One point: an amber dot and a line of text. */
    private View point(@NonNull String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextAppearance(R.style.TextAppearance_Confess_BodyMedium);
        t.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
        t.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.dot_amber, 0, 0, 0);
        t.setCompoundDrawablePadding(dp(12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        t.setLayoutParams(lp);
        return t;
    }

    // ── Dots ─────────────────────────────────────────────────────────────────

    private void buildDots() {
        b.dots.removeAllViews();
        for (int i = 0; i < pages.size(); i++) {
            View d = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(6), dp(6));
            lp.setMarginStart(dp(3));
            lp.setMarginEnd(dp(3));
            d.setLayoutParams(lp);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dp(3));
            d.setBackground(g);
            b.dots.addView(d);
        }
    }

    /** The current page's dot stretches into an amber pill. */
    private void paintDots() {
        int amber = ContextCompat.getColor(this, R.color.amber);
        int off = ContextCompat.getColor(this, R.color.hairline);
        for (int i = 0; i < b.dots.getChildCount(); i++) {
            View d = b.dots.getChildAt(i);
            boolean on = i == index;
            ((GradientDrawable) d.getBackground()).setColor(on ? amber : off);
            int target = dp(on ? 18 : 6);
            LinearLayout.LayoutParams lp = (LinearLayout.LayoutParams) d.getLayoutParams();
            if (lp.width == target) continue;
            if (!ValueAnimator.areAnimatorsEnabled()) {
                lp.width = target;
                d.setLayoutParams(lp);
                continue;
            }
            ValueAnimator a = ValueAnimator.ofInt(lp.width, target);
            a.setDuration(220);
            a.addUpdateListener(x -> {
                lp.width = (int) x.getAnimatedValue();
                d.setLayoutParams(lp);
            });
            a.start();
        }
    }

    /** The icon floats gently up and down while you read. */
    private void startFloating() {
        if (!ValueAnimator.areAnimatorsEnabled()) return;
        floatAnim = ValueAnimator.ofFloat(-dp(4), dp(4));
        floatAnim.setDuration(1800);
        floatAnim.setRepeatMode(ValueAnimator.REVERSE);
        floatAnim.setRepeatCount(ValueAnimator.INFINITE);
        floatAnim.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());
        floatAnim.addUpdateListener(a -> b.iconDisc.setTranslationY((float) a.getAnimatedValue()));
        floatAnim.start();
    }

    private void finishTour() {
        Tour.markSeen(this);
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()));
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt(STATE_INDEX, index);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (floatAnim != null) floatAnim.cancel();
        super.onDestroy();
    }
}
